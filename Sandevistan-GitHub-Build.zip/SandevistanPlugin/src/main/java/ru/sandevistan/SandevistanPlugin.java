package ru.sandevistan;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class SandevistanPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final Material ITEM_MATERIAL = Material.CARROT_ON_A_STICK;

    private NamespacedKey itemKey;
    private NamespacedKey jumpKey;
    private final Set<UUID> active = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        itemKey = new NamespacedKey(this, "sandevistan");
        jumpKey = new NamespacedKey(this, "sandevistan_jump");
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("sandevistan") != null) {
            getCommand("sandevistan").setExecutor(this);
            getCommand("sandevistan").setTabCompleter(this);
        }
    }

    // ---------- предмет ----------

    private ItemStack createItem() {
        ItemStack item = new ItemStack(ITEM_MATERIAL);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text("Сандевистан", NamedTextColor.AQUA)
                .decorate(TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Правый клик — включить", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("Враги вокруг слабеют", NamedTextColor.DARK_AQUA)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        // картинка из ресурспака (sdpack:sandevistan)
        meta.setItemModel(new NamespacedKey("sdpack", "sandevistan"));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isSandevistan(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
    }

    private boolean isAllowed(Player p) {
        return p.hasPermission("sandevistan.use")
                || getConfig().getStringList("allowed").contains(p.getUniqueId().toString());
    }

    // ---------- команды ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("sandevistan.admin")) {
            sender.sendMessage(Component.text("Нет доступа.", NamedTextColor.RED));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(Component.text("/sandevistan <give [ник] | allow <ник> | deny <ник> | reload>", NamedTextColor.GRAY));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give" -> {
                Player target;
                if (args.length > 1) {
                    target = Bukkit.getPlayerExact(args[1]);
                } else if (sender instanceof Player self) {
                    target = self;
                } else {
                    sender.sendMessage("Укажи ник игрока.");
                    return true;
                }
                if (target == null) {
                    sender.sendMessage(Component.text("Игрок не в сети.", NamedTextColor.RED));
                    return true;
                }
                target.getInventory().addItem(createItem());
                sender.sendMessage(Component.text("Сандевистан выдан: " + target.getName(), NamedTextColor.AQUA));
            }
            case "allow", "deny" -> {
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Укажи ник игрока.", NamedTextColor.RED));
                    return true;
                }
                @SuppressWarnings("deprecation")
                OfflinePlayer op = Bukkit.getOfflinePlayer(args[1]);
                String uuid = op.getUniqueId().toString();
                List<String> list = new ArrayList<>(getConfig().getStringList("allowed"));
                if (args[0].equalsIgnoreCase("allow")) {
                    if (!list.contains(uuid)) list.add(uuid);
                    sender.sendMessage(Component.text(args[1] + " теперь может пользоваться сандевистаном.", NamedTextColor.GREEN));
                } else {
                    list.remove(uuid);
                    sender.sendMessage(Component.text(args[1] + " больше не может пользоваться.", NamedTextColor.YELLOW));
                }
                getConfig().set("allowed", list);
                saveConfig();
            }
            case "reload" -> {
                reloadConfig();
                sender.sendMessage(Component.text("Конфиг перезагружен.", NamedTextColor.GREEN));
            }
            default -> sender.sendMessage(Component.text("Неизвестная подкоманда.", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("give", "allow", "deny", "reload");
        return null; // ники игроков подставит сам Paper
    }

    // ---------- использование ----------

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isSandevistan(e.getItem())) return;

        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!isAllowed(p)) {
            p.sendActionBar(Component.text("Этот имплант не для тебя", NamedTextColor.RED));
            return;
        }
        activate(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        active.remove(e.getPlayer().getUniqueId());
    }

    private void activate(Player p) {
        UUID id = p.getUniqueId();
        if (active.contains(id)) return;
        if (p.hasCooldown(ITEM_MATERIAL)) {
            p.sendActionBar(Component.text("Имплант остывает...", NamedTextColor.RED));
            return;
        }

        final int durationTicks = getConfig().getInt("duration-seconds", 15) * 20;
        final int cooldownTicks = getConfig().getInt("cooldown-seconds", 5) * 20;
        final double radius = getConfig().getDouble("radius", 50);
        final double radiusSq = radius * radius;

        active.add(id);
        p.setCooldown(ITEM_MATERIAL, durationTicks + cooldownTicks);

        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, durationTicks, 5, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, durationTicks, 3, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, durationTicks, 2, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, durationTicks, 1, false, false, false));
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;
            final Set<UUID> affected = new HashSet<>();

            @Override
            public void run() {
                if (!p.isOnline() || p.isDead() || ticks >= durationTicks) {
                    finish();
                    cancel();
                    return;
                }

                World w = p.getWorld();
                Location center = p.getLocation().add(0, 1, 0);

                // шлейф
                w.spawnParticle(Particle.DUST, center, 10, 0.3, 0.6, 0.3, 0,
                        new Particle.DustOptions(Color.fromRGB(0, 255, 230), 1.6f));
                w.spawnParticle(Particle.END_ROD, center, 2, 0.2, 0.5, 0.2, 0.01);

                // враги вокруг: утомление и сниженный прыжок
                Location pl = p.getLocation();
                for (Entity en : p.getNearbyEntities(radius, radius, radius)) {
                    if (!(en instanceof LivingEntity) || en instanceof ArmorStand) continue;
                    LivingEntity le = (LivingEntity) en;
                    if (le.getLocation().distanceSquared(pl) > radiusSq) continue;

                    le.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 10, 4, false, false, false));

                    AttributeInstance jump = le.getAttribute(Attribute.JUMP_STRENGTH);
                    if (jump != null && jump.getModifier(jumpKey) == null) {
                        // временный модификатор: сам не сохраняется в мобе
                        jump.addTransientModifier(new AttributeModifier(jumpKey, -0.7,
                                AttributeModifier.Operation.ADD_SCALAR));
                        affected.add(le.getUniqueId());
                    }
                }

                // таймер над хотбаром раз в секунду
                if (ticks % 20 == 0) {
                    int left = (durationTicks - ticks) / 20;
                    p.sendActionBar(Component.text("САНДЕВИСТАН  " + left + "с", NamedTextColor.AQUA)
                            .decorate(TextDecoration.BOLD));
                }
                ticks++;
            }

            private void finish() {
                // возвращаем врагам нормальный прыжок
                for (UUID u : affected) {
                    Entity en = Bukkit.getEntity(u);
                    if (en instanceof LivingEntity le) {
                        AttributeInstance jump = le.getAttribute(Attribute.JUMP_STRENGTH);
                        if (jump != null) jump.removeModifier(jumpKey);
                    }
                }
                affected.clear();
                active.remove(id);
                if (p.isOnline()) {
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.7f);
                    p.sendActionBar(Component.text("Сандевистан выключен", NamedTextColor.GRAY));
                }
            }
        }.runTaskTimer(this, 0L, 1L);
    }
}
